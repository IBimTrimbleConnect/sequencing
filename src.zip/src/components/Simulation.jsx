import {
  Button,
  DatePicker,
  Select,
  Slider,
  Space,
  Switch,
  Tooltip,
} from "antd";

import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";

import {
  StepBackwardOutlined,
  StepForwardOutlined,
  PlayCircleOutlined,
  PauseCircleOutlined,
} from "@ant-design/icons";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { useDispatch, useSelector } from "react-redux";

import * as WorkspaceAPI from "trimble-connect-workspace-api";

import {
  SetActiveSimulationItem,
  SetSimulationDateRange,
} from "../store/sequence/action";

import {
  addSimulationFrame,
  clearSimulationFrames,
} from "../services/simulationVideoService";

dayjs.extend(customParseFormat);

const DATE_FORMATS = ["DD-MM-YYYY", "DD/MM/YYYY", "YYYY-MM-DD", "YYYY/MM/DD"];

const ALL_PLANS_VALUE = "__ALL_PLANS__";
const ALL_SUBPLANS_VALUE = "__ALL_SUBPLANS__";

const SNAPSHOT_RENDER_DELAY_MS = 150;

/*
 * Vertical leader offset for the current Simulation text markup.
 * Viewer/world coordinates are in millimeters.
 */
const TEXT_MARKUP_MIN_OFFSET_MM = 500;
const TEXT_MARKUP_HEIGHT_RATIO = 0.2;

/*
 * Viewer object bounding-box coordinates are returned in viewer/model
 * coordinates (meters), while MarkupPick.positionX/Y/Z require millimeters.
 */
const METERS_TO_MILLIMETERS = 1000;

const DEFAULT_PROJECT_FORMATTING = {
  massUnit: "kg",
  massDecimals: 2,
};

const normalizeRgbColor = (color) => {
  if (!color) {
    return null;
  }

  if (typeof color === "string") {
    const normalized = color.trim().replace(/^#/, "");

    if (/^[0-9a-fA-F]{3}$/.test(normalized)) {
      return {
        r: Number.parseInt(normalized[0] + normalized[0], 16),
        g: Number.parseInt(normalized[1] + normalized[1], 16),
        b: Number.parseInt(normalized[2] + normalized[2], 16),
      };
    }

    if (/^[0-9a-fA-F]{6}$/.test(normalized)) {
      return {
        r: Number.parseInt(normalized.slice(0, 2), 16),
        g: Number.parseInt(normalized.slice(2, 4), 16),
        b: Number.parseInt(normalized.slice(4, 6), 16),
      };
    }

    return null;
  }

  if (typeof color === "object") {
    const r = Number(color.r);
    const g = Number(color.g);
    const b = Number(color.b);

    if (Number.isFinite(r) && Number.isFinite(g) && Number.isFinite(b)) {
      return {
        r: Math.max(0, Math.min(255, r)),
        g: Math.max(0, Math.min(255, g)),
        b: Math.max(0, Math.min(255, b)),
      };
    }
  }

  return null;
};

const normalizeUnit = (unit) =>
  String(unit || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-");

const roundByDecimals = (value, decimals = 2) => {
  const numericValue = Number(value);

  if (!Number.isFinite(numericValue)) {
    return null;
  }

  const numericDecimals = Number(decimals);

  const safeDecimals = Number.isInteger(numericDecimals)
    ? Math.max(0, numericDecimals)
    : 2;

  const factor = 10 ** safeDecimals;

  return Math.round((numericValue + Number.EPSILON) * factor) / factor;
};

const convertMassFromKg = (value, formatting = DEFAULT_PROJECT_FORMATTING) => {
  const massKg = Number(value);

  if (!Number.isFinite(massKg)) {
    return null;
  }

  const targetUnit = normalizeUnit(formatting?.massUnit || "kg");

  const decimals = formatting?.massDecimals ?? 2;

  let convertedValue = massKg;

  switch (targetUnit) {
    case "mg":
    case "milligram":
    case "milligrams":
      convertedValue = massKg * 1_000_000;
      break;

    case "g":
    case "gram":
    case "grams":
      convertedValue = massKg * 1000;
      break;

    case "kg":
    case "kilogram":
    case "kilograms":
      convertedValue = massKg;
      break;

    /*
     * Metric tonne
     */
    case "t":
    case "tonne":
    case "tonnes":
    case "metric-ton":
    case "metricton":
      convertedValue = massKg / 1000;
      break;

    case "oz":
    case "ounce":
    case "ounces":
      convertedValue = massKg * 35.2739619496;
      break;

    case "lb":
    case "lbs":
    case "pound":
    case "pounds":
      convertedValue = massKg * 2.20462262185;
      break;

    /*
     * US short ton
     */
    case "ton":
    case "short-ton":
    case "shortton":
      convertedValue = massKg / 907.18474;
      break;

    /*
     * Imperial long ton
     */
    case "long-ton":
    case "longton":
      convertedValue = massKg / 1016.0469088;
      break;

    default:
      convertedValue = massKg;
      break;
  }

  return roundByDecimals(convertedValue, decimals);
};

const getDisplayMassUnit = (formatting = DEFAULT_PROJECT_FORMATTING) => {
  const unit = normalizeUnit(formatting?.massUnit || "kg");

  switch (unit) {
    case "milligram":
    case "milligrams":
      return "mg";

    case "gram":
    case "grams":
      return "g";

    case "kilogram":
    case "kilograms":
      return "kg";

    case "lbs":
    case "pound":
    case "pounds":
      return "lb";

    case "ounce":
    case "ounces":
      return "oz";

    case "tonne":
    case "tonnes":
    case "metric-ton":
    case "metricton":
      return "t";

    case "short-ton":
    case "shortton":
      return "ton";

    case "longton":
      return "long-ton";

    default:
      return unit || "kg";
  }
};

export default function Simulation({
  loadedModelIds = [],
  simulationRequest = null,
  simulationData = null,
  onSimulationRequestApplied,
}) {
  const dispatch = useDispatch();

  const reduxPlans = useSelector((state) => state.sequence.plans || []);

  const reduxSequenceObjects = useSelector(
    (state) => state.sequence.sequenceObjects || [],
  );

  const reduxSubPlans = useSelector((state) => state.sequence.subPlans || []);

  const plans = simulationData?.plans || reduxPlans;
  const sequenceObjects = simulationData?.sequenceObjects || reduxSequenceObjects;
  const subPlans = simulationData?.subPlans || reduxSubPlans;

  const tcapiRef = useRef(null);
  const intervalRef = useRef(null);

  /*
   * Serialize every Trimble Viewer mutation.
   *
   * Trimble viewer methods return Promise<void>. "await" guarantees
   * ordering only inside one async function. Without this queue,
   * goToIndex(), transparency changes and Grid changes can still run
   * at the same time and overwrite each other's viewer state.
   */
  const viewerTaskRef = useRef(Promise.resolve());

  /*
   * Keep the current index available to the async autoplay loop
   * without creating overlapping setInterval callbacks.
   */
  const indexRef = useRef(0);

  /*
   * Used to ignore stale transparency tasks while the user is
   * dragging the transparency slider quickly.
   */
  const transparencyTaskIdRef = useRef(0);

  const simulationActivatedRef = useRef(false);

  const gridObjectsRef = useRef(null);

  /*
   * Keep one TextMarkup for the active Simulation object.
   *
   * addTextMarkup() updates an existing markup when the same id is sent,
   * so the simulation does not create a new markup on every step.
   */
  const simulationTextMarkupIdRef = useRef(null);

  const simulationTextMarkupTaskIdRef = useRef(0);

  /*
   * Simulation only captures snapshots.
   *
   * The actual frames are stored in simulationVideoService so TopMenu can
   * export them later without putting large Data URLs into Redux.
   */
  const snapshotIndexRef = useRef(0);
  const recordingSimulationRef = useRef(false);
  const simulationPausedRef = useRef(false);

  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [delay, setDelay] = useState(200);
  const [transparency, setTransparency] = useState(0);

  const [projectFormatting, setProjectFormatting] = useState(
    DEFAULT_PROJECT_FORMATTING,
  );

  const [selectedPlanIds, setSelectedPlanIds] = useState([]);

  const [selectedSubPlanIds, setSelectedSubPlanIds] = useState([]);

  const [startDate, setStartDate] = useState(null);

  const [endDate, setEndDate] = useState(null);

  const [showGrid, setShowGrid] = useState(false);

  /*
   * When Run Simulation is clicked from a Plan menu,
   * first update the existing filters, then wait for `items`
   * to be recalculated, and only then start playback.
   */
  const [pendingSimulationRequest, setPendingSimulationRequest] =
    useState(null);

  const getTcapi = useCallback(async () => {
    if (!tcapiRef.current) {
      tcapiRef.current = await WorkspaceAPI.connect(window.parent);
    }

    return tcapiRef.current;
  }, []);

  /*
   * =====================================================
   * CURRENT OBJECT TEXT MARKUP
   * =====================================================
   *
   * TextMarkup requires start + end MarkupPick values.
   *
   * We anchor `start` at the top-center of the object's bounding box
   * and place `end` above it. The text is therefore connected to the
   * current object with a leader line.
   *
   * Trimble coordinates are in millimeters.
   */
  const removeSimulationTextMarkup = useCallback(async () => {
    const markupId = simulationTextMarkupIdRef.current;

    /*
     * Invalidate an older asynchronous update that may still be waiting
     * on getObjectBoundingBoxes().
     */
    simulationTextMarkupTaskIdRef.current += 1;

    if (markupId == null) {
      return;
    }

    try {
      const tcapi = await getTcapi();

      await tcapi.markup.removeMarkups([markupId]);
    } catch (error) {
      console.warn("Remove simulation text markup failed:", error);
    } finally {
      simulationTextMarkupIdRef.current = null;
    }
  }, [getTcapi]);

  const buildSimulationMarkupText = useCallback(
    (item) => {
      if (!item) {
        return "";
      }

      const lines = [];

      const assemblyPosition =
        item?.asmPos || item?.name || item?.objectName || "";

      if (assemblyPosition) {
        lines.push(String(assemblyPosition));
      }

      const gridPosition =
        item?.positionCode || item?.gridPos || item?.location || "";

      if (gridPosition) {
        lines.push(`Grid: ${gridPosition}`);
      }

      if (item?.weight != null && Number.isFinite(Number(item.weight))) {
        const convertedWeight = convertMassFromKg(
          item.weight,
          projectFormatting,
        );

        if (convertedWeight != null) {
          lines.push(
            `Weight: ${convertedWeight} ${getDisplayMassUnit(
              projectFormatting,
            )}`,
          );
        }
      }

      if (item?.simulationDate) {
        lines.push(`Date: ${item.simulationDate}`);
      }

      return lines.join("\n");
    },
    [projectFormatting],
  );

  const showSimulationTextMarkup = useCallback(
    async (item) => {
      if (item?.modelId == null || item?.runtimeId == null) {
        return;
      }

      const taskId = ++simulationTextMarkupTaskIdRef.current;

      try {
        const tcapi = await getTcapi();

        /*
         * Use the object's actual bounding box instead of guessing a
         * markup coordinate. getObjectBoundingBoxes() accepts runtime ids.
         */
        const boundingBoxes = await tcapi.viewer.getObjectBoundingBoxes(
          item.modelId,
          [item.runtimeId],
        );

        if (taskId !== simulationTextMarkupTaskIdRef.current) {
          return;
        }

        const objectBoundingBox = Array.isArray(boundingBoxes)
          ? boundingBoxes.find(
              (entry) => String(entry?.id) === String(item.runtimeId),
            ) || boundingBoxes[0]
          : null;

        const box = objectBoundingBox?.boundingBox;

        const min = box?.min;

        const max = box?.max;

        if (!min || !max) {
          console.warn(
            "Unable to create Simulation text markup: object bounding box is empty.",
            item,
          );

          return;
        }

        const minX = Number(min.x);

        const minY = Number(min.y);

        const minZ = Number(min.z);

        const maxX = Number(max.x);

        const maxY = Number(max.y);

        const maxZ = Number(max.z);

        if (![minX, minY, minZ, maxX, maxY, maxZ].every(Number.isFinite)) {
          console.warn(
            "Unable to create Simulation text markup: invalid bounding box coordinates.",
            box,
          );

          return;
        }

        /*
         * getObjectBoundingBoxes() follows Viewer/model coordinates.
         * MarkupPick coordinates are explicitly millimeters.
         *
         * Convert the object center to millimeters before passing it
         * to addTextMarkup(). Without this conversion the markup can
         * appear far away from the selected object.
         */
        const centerX = ((minX + maxX) / 2) * METERS_TO_MILLIMETERS;

        const centerY = ((minY + maxY) / 2) * METERS_TO_MILLIMETERS;

        const centerZ = ((minZ + maxZ) / 2) * METERS_TO_MILLIMETERS;

        const height = Math.max(0, (maxZ - minZ) * METERS_TO_MILLIMETERS);

        const leaderOffset = Math.max(
          TEXT_MARKUP_MIN_OFFSET_MM,
          height * TEXT_MARKUP_HEIGHT_RATIO,
        );

        const externalId =
          item?.externalId ?? item?.external_id ?? item?.objectId ?? null;

        /*
         * Anchor point attached to the model object.
         */
        const startPick = {
          type: "point",

          modelId: String(item.modelId),

          objectId: Number(item.runtimeId),

          ...(externalId
            ? {
                referenceObjectId: String(externalId),
              }
            : {}),

          positionX: centerX,

          positionY: centerY,

          positionZ: centerZ,
        };

        /*
         * Text position. This pick is intentionally free in model space,
         * slightly above the object's upper bounding-box face.
         */
        const endPick = {
          type: "point",

          positionX: centerX,

          positionY: centerY,

          positionZ: centerZ + leaderOffset,
        };

        const markup = {
          ...(simulationTextMarkupIdRef.current != null
            ? {
                id: simulationTextMarkupIdRef.current,
              }
            : {}),

          start: startPick,

          end: endPick,

          text: buildSimulationMarkupText(item),

          color: {
            r: 255,

            g: 0,

            b: 255,

            a: 255,
          },
        };

        const addedMarkups = await tcapi.markup.addTextMarkup([markup]);

        if (taskId !== simulationTextMarkupTaskIdRef.current) {
          return;
        }

        const returnedMarkup = Array.isArray(addedMarkups)
          ? addedMarkups[0]
          : null;

        if (returnedMarkup?.id != null) {
          simulationTextMarkupIdRef.current = returnedMarkup.id;
        }
      } catch (error) {
        console.error("Add/update Simulation text markup failed:", error);
      }
    },
    [buildSimulationMarkupText, getTcapi],
  );

  /*
   * Reset the recording session.
   *
   * This is called only when a NEW simulation starts. Pause/resume keeps the
   * existing captured frames.
   */
  const clearCapturedFrames = useCallback(() => {
    clearSimulationFrames();

    snapshotIndexRef.current = 0;
    recordingSimulationRef.current = false;
    simulationPausedRef.current = false;
  }, []);

  useEffect(() => {
    indexRef.current = index;
  }, [index]);

  /*
   * =====================================================
   * RUN SIMULATION FROM PLAN / SUBPLAN MENU
   * =====================================================
   *
   * Reuse this single Simulation engine.
   */
  useEffect(() => {
    const requestedPlanId = simulationRequest?.planId;

    if (!requestedPlanId) {
      return;
    }

    const planId = String(requestedPlanId);

    const requestedSubPlanId =
      simulationRequest?.subPlanId != null
        ? String(simulationRequest.subPlanId)
        : null;

    const planExists = plans.some((plan) => String(plan?.id) === planId);

    if (!planExists) {
      onSimulationRequestApplied?.();
      return;
    }

    setPlaying(false);
    clearTimeout(intervalRef.current);

    indexRef.current = 0;
    setIndex(0);

    setSelectedPlanIds([planId]);

    if (requestedSubPlanId) {
      setSelectedSubPlanIds([requestedSubPlanId]);
    } else {
      const planSubPlanIds = subPlans
        .filter(
          (subPlan) =>
            String(subPlan?.planId ?? subPlan?.parentPlanId ?? "") === planId,
        )
        .map((subPlan) => String(subPlan.id));

      setSelectedSubPlanIds(planSubPlanIds);
    }

    setStartDate(null);
    setEndDate(null);

    setPendingSimulationRequest({
      planId,
      subPlanId: requestedSubPlanId,
    });
  }, [simulationRequest, plans, subPlans, onSimulationRequestApplied, simulationData]);

  /*
   * modelId và runtimeId đã được hydrate trong saga.
   * Simulation chỉ đọc dữ liệu runtime từ Redux.
   */

  const parseDate = useCallback((value) => {
    if (!value) {
      return null;
    }

    if (dayjs.isDayjs(value)) {
      return value.isValid() ? value : null;
    }

    const strictDate = dayjs(value, DATE_FORMATS, true);

    if (strictDate.isValid()) {
      return strictDate;
    }

    const normalDate = dayjs(value);

    return normalDate.isValid() ? normalDate : null;
  }, []);

  useEffect(() => {
    const validPlanIds = plans.map((plan) => String(plan.id));

    setSelectedPlanIds((current) => {
      if (!current.length) {
        return validPlanIds;
      }

      const existingSelectedIds = current.filter((id) =>
        validPlanIds.includes(String(id)),
      );

      /*
       * Preserve explicit selection, especially [Plan A]
       * after Run Simulation is clicked from the Plan menu.
       */
      if (existingSelectedIds.length) {
        return existingSelectedIds;
      }

      return validPlanIds;
    });
  }, [plans]);

  const availableSubPlans = useMemo(() => {
    const selectedPlanSet = new Set(selectedPlanIds.map((id) => String(id)));

    return subPlans.filter((subPlan) => {
      const subPlanPlanId = subPlan.planId ?? subPlan.parentPlanId;

      if (subPlanPlanId == null) {
        return true;
      }

      return selectedPlanSet.has(String(subPlanPlanId));
    });
  }, [subPlans, selectedPlanIds]);

  // =====================================================
  // DEFAULT SELECT ALL AVAILABLE SUB PLANS
  // =====================================================

  useEffect(() => {
    const validSubPlanIds = availableSubPlans.map((subPlan) =>
      String(subPlan.id),
    );

    setSelectedSubPlanIds((current) => {
      const existingSelectedIds = current.filter((id) =>
        validSubPlanIds.includes(String(id)),
      );

      if (existingSelectedIds.length) {
        return existingSelectedIds;
      }

      return validSubPlanIds;
    });
  }, [availableSubPlans]);

  // =====================================================
  // BUILD ALL SIMULATION ITEMS
  // =====================================================

  const allItems = useMemo(() => {
    if (!sequenceObjects.length) {
      return [];
    }

    const result = [];
    let originalIndex = 0;

    sequenceObjects.forEach((group, groupIndex) => {
      if (!group) {
        return;
      }

      const objects = Array.isArray(group.objects) ? group.objects : [];

      objects.forEach((obj, objectIndex) => {
        const modelId = obj?.modelId ?? group?.modelId ?? null;

        const runtimeId = obj?.runtimeId ?? null;

        const externalId = obj?.externalId ?? obj?.external_id ?? null;

        const planId = String(obj?.planId ?? group?.planId ?? "");

        const subPlanId = String(obj?.subPlanId ?? group?.subPlanId ?? "");

        const simulationDate = obj?.assignedDate || obj?.date;

        const parsedDate = parseDate(simulationDate);

        /*
         * Runtime ID đã được hydrate trong saga.
         * Simulation không convert lại external_id.
         */
        if (
          modelId == null ||
          runtimeId == null ||
          !parsedDate ||
          obj?.objectAvailable === false
        ) {
          return;
        }

        const plan = plans.find((item) => String(item.id) === planId);

        result.push({
          ...obj,

          modelId,
          runtimeId,
          externalId,

          planId,
          subPlanId,

          groupIndex,
          objectIndex,

          originalIndex: originalIndex++,

          planName: plan?.name || group?.planName || `Plan ${groupIndex + 1}`,

          name:
            obj?.asmPos ||
            obj?.name ||
            obj?.objectName ||
            `Object ${objectIndex + 1}`,

          /*
           * Giữ externalId để Redux/UI nhận diện ổn định.
           * Viewer luôn sử dụng runtimeId.
           */
          objectId: externalId,

          simulationDate: parsedDate.format("DD-MM-YYYY"),

          simulationTime: parsedDate.valueOf(),
        });
      });
    });

    return result.sort((a, b) => {
      if (a.simulationTime !== b.simulationTime) {
        return a.simulationTime - b.simulationTime;
      }

      return a.originalIndex - b.originalIndex;
    });
  }, [sequenceObjects, plans, parseDate]);

  // =====================================================
  // FILTER ITEMS
  // =====================================================

  const items = useMemo(() => {
    const selectedPlanSet = new Set(selectedPlanIds.map((id) => String(id)));

    const selectedSubPlanSet = new Set(
      selectedSubPlanIds.map((id) => String(id)),
    );

    const start = startDate ? dayjs(startDate).startOf("day") : null;

    const end = endDate ? dayjs(endDate).endOf("day") : null;

    const filtered = allItems.filter((item) => {
      if (!selectedPlanSet.has(String(item.planId))) {
        return false;
      }

      if (
        item.subPlanId &&
        selectedSubPlanSet.size &&
        !selectedSubPlanSet.has(String(item.subPlanId))
      ) {
        return false;
      }

      const itemDate = parseDate(item.simulationDate);

      if (!itemDate) {
        return false;
      }

      if (start && itemDate.isBefore(start, "day")) {
        return false;
      }

      if (end && itemDate.isAfter(end, "day")) {
        return false;
      }

      return true;
    });

    return filtered;
  }, [
    allItems,
    selectedPlanIds,
    selectedSubPlanIds,
    startDate,
    endDate,
    parseDate,
  ]);

  const current = items[index];

  /*
   * Convert weight từ kg sang massUnit của project.
   */
  const displayWeight = useMemo(() => {
    if (current?.weight == null || !Number.isFinite(Number(current.weight))) {
      return null;
    }

    return convertMassFromKg(current.weight, projectFormatting);
  }, [current?.weight, projectFormatting]);

  const displayWeightUnit = useMemo(
    () => getDisplayMassUnit(projectFormatting),
    [projectFormatting],
  );

  // =====================================================
  // RESET SIMULATION WHEN FILTER CHANGES
  // =====================================================

  useEffect(() => {
    recordingSimulationRef.current = false;
    setPlaying(false);
    setIndex(0);
    clearCapturedFrames();

    clearTimeout(intervalRef.current);

    removeSimulationTextMarkup();
  }, [
    selectedPlanIds,
    selectedSubPlanIds,
    startDate,
    endDate,
    clearCapturedFrames,
    removeSimulationTextMarkup,
  ]);

  /*
   * Chỉ kiểm tra index.
   * Không gọi isolateEntities khi items thay đổi.
   */
  useEffect(() => {
    if (!items.length) {
      setIndex(0);
      setPlaying(false);

      clearTimeout(intervalRef.current);

      removeSimulationTextMarkup();

      return;
    }

    if (index >= items.length) {
      setIndex(items.length - 1);
    }
  }, [items.length, index, removeSimulationTextMarkup]);

  // =====================================================
  // SAVE DATE RANGE TO REDUX
  // =====================================================

  useEffect(() => {
    dispatch(
      SetSimulationDateRange({
        startDate: startDate ? startDate.format("DD-MM-YYYY") : null,

        endDate: endDate ? endDate.format("DD-MM-YYYY") : null,
      }),
    );
  }, [startDate, endDate, dispatch]);

  // =====================================================
  // TRIMBLE CONNECT API
  // =====================================================

  const captureSimulationSnapshot = useCallback(
    async (item, itemIndex) => {
      if (!recordingSimulationRef.current) {
        return;
      }

      try {
        const tcapi = await getTcapi();

        /*
         * Viewer API promises are ordered, but give the host viewer a small
         * render window before taking the screenshot.
         */
        await new Promise((resolve) => {
          window.setTimeout(resolve, SNAPSHOT_RENDER_DELAY_MS);
        });

        const snapshot = await tcapi.viewer.getSnapshot();

        if (!snapshot) {
          console.warn("Simulation snapshot is empty:", itemIndex);

          return;
        }

        addSimulationFrame({
          index: snapshotIndexRef.current++,
          itemIndex,
          planId: item?.planId ?? null,
          subPlanId: item?.subPlanId ?? null,
          modelId: item?.modelId ?? null,
          runtimeId: item?.runtimeId ?? null,

          /*
           * Keep the delay used for this frame.
           * TopMenu uses this value when composing the MP4.
           */
          duration: Math.max(50, Number(delay) || 200),

          snapshot,
        });

        console.log("Simulation snapshot captured:", itemIndex);
      } catch (error) {
        console.error("Capture simulation snapshot failed:", error);
      }
    },
    [delay, getTcapi],
  );

  const enqueueViewerTask = useCallback((task) => {
    const nextTask = viewerTaskRef.current
      .catch(() => {
        /*
         * A failed previous task must not break the queue.
         */
      })
      .then(task);

    /*
     * Keep a non-rejecting tail in the queue, while still returning
     * the original Promise so the caller can await/catch its error.
     */
    viewerTaskRef.current = nextTask.catch(() => {});

    return nextTask;
  }, []);

  /*
   * Lấy Project Unit Setting một lần khi component load.
   */
  useEffect(() => {
    let mounted = true;

    const loadProjectFormatting = async () => {
      try {
        const tcapi = await getTcapi();

        const settings = await tcapi.project.getSettings();

        const formatting = settings?.formatting || {};

        if (!mounted) {
          return;
        }

        const nextFormatting = {
          massUnit: formatting.massUnit || DEFAULT_PROJECT_FORMATTING.massUnit,

          massDecimals:
            formatting.massDecimals ?? DEFAULT_PROJECT_FORMATTING.massDecimals,
        };

        setProjectFormatting(nextFormatting);

        console.log("Simulation project formatting:", nextFormatting);
      } catch (error) {
        console.error("Get project formatting failed:", error);

        if (mounted) {
          setProjectFormatting(DEFAULT_PROJECT_FORMATTING);
        }
      }
    };

    loadProjectFormatting();

    return () => {
      mounted = false;
    };
  }, [getTcapi]);

  const buildAccumulatedObjects = useCallback(
    (toIndex) => {
      const modelMap = new Map();

      items.slice(0, toIndex + 1).forEach((item) => {
        if (item.modelId == null || item.runtimeId == null) {
          return;
        }

        const modelKey = String(item.modelId);

        if (!modelMap.has(modelKey)) {
          modelMap.set(modelKey, {
            modelId: item.modelId,

            entityIds: [],
          });
        }

        modelMap.get(modelKey).entityIds.push(item.runtimeId);
      });

      return Array.from(modelMap.values()).map((group) => ({
        ...group,

        entityIds: [...new Set(group.entityIds)],
      }));
    },
    [items],
  );

  const selectObjectInTrimble = useCallback(
    async (item) => {
      if (item?.modelId == null || item?.runtimeId == null) {
        return;
      }

      const tcapi = await getTcapi();

      await tcapi.viewer.setSelection(
        {
          modelObjectIds: [
            {
              modelId: item.modelId,

              objectRuntimeIds: [item.runtimeId],
            },
          ],
        },
        "set",
      );
    },
    [getTcapi],
  );

  const colorObjectInTrimble = useCallback(
    async (item) => {
      if (item?.modelId == null || item?.runtimeId == null) {
        return;
      }

      const subPlan = subPlans.find(
        (subPlanItem) => String(subPlanItem.id) === String(item.subPlanId),
      );

      const color = normalizeRgbColor(subPlan?.color);

      if (!color) {
        return;
      }

      const tcapi = await getTcapi();
      await tcapi.viewer.setObjectState(
        {
          modelObjectIds: [
            {
              modelId: item.modelId,

              objectRuntimeIds: [item.runtimeId],
            },
          ],
        },
        {
          color,
          visible: true,
          opacity: 100,
        },
      );
    },
    [getTcapi, subPlans],
  );

  const colorAccumulatedObjects = useCallback(
    async (toIndex) => {
      const completedItems = items.slice(0, toIndex + 1);

      for (const completedItem of completedItems) {
        await colorObjectInTrimble(completedItem);
      }
    },
    [items, colorObjectInTrimble],
  );

  const gotoCamera = useCallback(
    async (item, objects) => {
      try {
        const tcapi = await getTcapi();

        if (item?.camera) {
          await tcapi.viewer.setCamera(item.camera, {
            animationTime: 1000,
          });

          return;
        }

        /*
         * Có thể bật lại setCamera theo selector nếu cần.
         */

        // if (!objects?.length) {
        //   return;
        // }

        // const selector = {
        //   modelObjectIds: objects
        //     .filter(
        //       (group) =>
        //         group.modelId != null &&
        //         Array.isArray(group.entityIds) &&
        //         group.entityIds.length > 0,
        //     )
        //     .map((group) => ({
        //       modelId: group.modelId,
        //       objectRuntimeIds: [
        //         ...new Set(group.entityIds),
        //       ],
        //     })),
        // };

        // if (!selector.modelObjectIds.length) {
        //   return;
        // }

        // await tcapi.viewer.setCamera(selector, {
        //   animationTime: 1000,
        // });
      } catch (error) {
        console.error("gotoCamera error:", error);
      }
    },
    [getTcapi],
  );

  const getGridObjects = useCallback(async () => {
    if (gridObjectsRef.current) {
      return gridObjectsRef.current;
    }

    const tcapi = await getTcapi();

    const result = await tcapi.viewer.getObjects({
      parameter: {
        class: "IFCGRID",
      },
    });

    gridObjectsRef.current = result || [];

    return gridObjectsRef.current;
  }, [getTcapi]);

  /*
   * includeGrid được truyền trực tiếp thay vì phụ thuộc showGrid.
   *
   * Nhờ vậy khi showGrid hoặc sequenceObjects thay đổi,
   * function không tự chạy lại thông qua useEffect.
   */
  const isolateObjectsInTrimble = useCallback(
    async (objects, includeGrid = false) => {
      if (!objects?.length) {
        return;
      }

      const tcapi = await getTcapi();

      const isolateObjects = objects
        .filter(
          (group) =>
            group?.modelId != null &&
            Array.isArray(group.entityIds) &&
            group.entityIds.length > 0,
        )
        .map((group) => ({
          modelId: group.modelId,

          entityIds: [...new Set(group.entityIds)],
        }));

      if (!isolateObjects.length) {
        return;
      }

      const modelMap = new Map(
        isolateObjects.map((group) => [String(group.modelId), group]),
      );

      if (includeGrid) {
        const grids = await getGridObjects();

        (grids || []).forEach((group) => {
          if (group?.modelId == null) {
            return;
          }

          const gridIds = (group.objects || [])
            .map((gridObject) => gridObject.id)
            .filter((gridId) => gridId != null);

          if (!gridIds.length) {
            return;
          }

          const modelKey = String(group.modelId);

          if (modelMap.has(modelKey)) {
            const target = modelMap.get(modelKey);

            target.entityIds = [...new Set([...target.entityIds, ...gridIds])];
          } else {
            const target = {
              modelId: group.modelId,

              entityIds: [...new Set(gridIds)],
            };

            isolateObjects.push(target);

            modelMap.set(modelKey, target);
          }
        });
      }

      await tcapi.viewer.isolateEntities(isolateObjects);
    },
    [getTcapi, getGridObjects],
  );
  const handleTransparencyChange = useCallback(
    async (value) => {
      const nextTransparency = Math.max(0, Math.min(100, Number(value) || 0));

      setTransparency(nextTransparency);

      if (
        !simulationActivatedRef.current ||
        !items.length ||
        index < 0 ||
        index >= items.length
      ) {
        return;
      }

      /*
       * Only the newest slider value needs to be applied.
       * Older queued transparency changes are skipped.
       */
      const taskId = ++transparencyTaskIdRef.current;

      try {
        await enqueueViewerTask(async () => {
          if (taskId !== transparencyTaskIdRef.current) {
            return;
          }

          const tcapi = await getTcapi();

          const accumulatedObjects = buildAccumulatedObjects(index);

          /*
           * Preserve the current behavior used by this version:
           * completed objects are updated individually.
           *
           * NOTE:
           * setObjectState.opacity is intentionally left using the
           * existing 0..1 calculation from this working version.
           * viewer.setOpacity() below is a different API and uses 0..100.
           */
          const opacity = Math.max(0, Math.min(1, 1 - nextTransparency / 100));

          for (const group of accumulatedObjects) {
            if (
              group?.modelId == null ||
              !Array.isArray(group.entityIds) ||
              !group.entityIds.length
            ) {
              continue;
            }

            if (taskId !== transparencyTaskIdRef.current) {
              return;
            }

            await tcapi.viewer.setObjectState(
              {
                modelObjectIds: [
                  {
                    modelId: group.modelId,

                    objectRuntimeIds: group.entityIds,
                  },
                ],
              },
              {
                opacity,
                visible: true,
              },
            );
          }
        });
      } catch (error) {
        console.error("Update simulation transparency failed:", error);
      }
    },
    [items.length, index, getTcapi, buildAccumulatedObjects, enqueueViewerTask],
  );

  const handleTransparencyChange1 = async (value) => {
    const nextTransparency = Math.max(0, Math.min(100, Number(value) || 0));

    setTransparency(nextTransparency);

    try {
      const tcapi = await getTcapi();

      if (nextTransparency > 0) {
        // await tcapi.viewer.setObjectState(undefined, {
        //   color: {
        //     r: 211,
        //     g: 211,
        //     b: 211,
        //   },
        //   opacity: nextTransparency,
        // });
        await tcapi.viewer.setOpacity(nextTransparency);
      } else {
        await tcapi.viewer.setOpacity(0);

        await tcapi.viewer.setObjectState(undefined, {
          color: "reset",
        });
      }
    } catch (error) {
      console.error("Update transparency failed:", error);
    }
  };

  // =====================================================
  // NAVIGATION
  // =====================================================

  const goToIndex = useCallback(
    async (newIndex) => {
      if (!items.length) {
        return;
      }

      const safeIndex = Math.max(0, Math.min(newIndex, items.length - 1));

      const item = items[safeIndex];

      if (!item) {
        return;
      }

      simulationActivatedRef.current = true;

      /*
       * Keep both React state and the async playback ref in sync.
       */
      indexRef.current = safeIndex;
      setIndex(safeIndex);

      dispatch(
        SetActiveSimulationItem({
          planId: String(item.planId),

          subPlanId: String(item.subPlanId),

          modelId: item.modelId,

          id: String(item.externalId ?? item.objectId ?? ""),

          objectId: item.externalId ?? item.objectId ?? null,

          runtimeId: item.runtimeId,
        }),
      );

      try {
        /*
         * Every Viewer mutation for this simulation step is executed
         * inside one queued task. This prevents another goToIndex(),
         * transparency change or Grid change from interleaving with it.
         */
        await enqueueViewerTask(async () => {
          const accumulatedObjects = buildAccumulatedObjects(safeIndex);

          const tcapi = await getTcapi();

          /*
           * viewer.setOpacity() returns Promise<void>.
           * Await it before changing object state.
           *
           * This working approach is intentionally preserved:
           * - transparency > 0: global viewer transparency + Light Grey
           * - transparency = 0: isolate accumulated objects
           */
          if (transparency === 0) {
            await isolateObjectsInTrimble(accumulatedObjects, showGrid);
          }

          // await gotoCamera(
          //   item,
          //   accumulatedObjects,
          // );

          /*
           * This runs only after setOpacity/setObjectState/isolate
           * has resolved.
           */
          await colorAccumulatedObjects(safeIndex);

          /*
           * Keep one TextMarkup attached to the current object.
           * The same markup id is updated as the simulation advances.
           */
          await showSimulationTextMarkup(item);

          /*
           * Capture only while simulation playback recording is active.
           * Manual slider/Next/Previous navigation does not add frames.
           * Snapshot is taken before selection so selection highlighting is
           * not baked into the exported video frame.
           */
          await captureSimulationSnapshot(item, safeIndex);

          await selectObjectInTrimble(item);
        });
      } catch (error) {
        console.error("Simulation viewer error:", error);
      }
    },
    [
      items,
      dispatch,
      showGrid,
      transparency,
      getTcapi,
      enqueueViewerTask,
      buildAccumulatedObjects,
      isolateObjectsInTrimble,
      gotoCamera,
      colorAccumulatedObjects,
      showSimulationTextMarkup,
      captureSimulationSnapshot,
      selectObjectInTrimble,
    ],
  );

  /*
   * =====================================================
   * AUTO START MENU SIMULATION
   * =====================================================
   */
  useEffect(() => {
    if (!pendingSimulationRequest) {
      return;
    }

    if (!items.length) {
      return;
    }

    const requestedPlanId = String(pendingSimulationRequest.planId);

    const requestedSubPlanId =
      pendingSimulationRequest.subPlanId != null
        ? String(pendingSimulationRequest.subPlanId)
        : null;

    const itemsMatchRequest = items.every((item) => {
      if (String(item?.planId) !== requestedPlanId) {
        return false;
      }

      if (
        requestedSubPlanId &&
        String(item?.subPlanId) !== requestedSubPlanId
      ) {
        return false;
      }

      return true;
    });

    if (!itemsMatchRequest) {
      return;
    }

    let cancelled = false;

    const startSimulation = async () => {
      try {
        clearCapturedFrames();
        recordingSimulationRef.current = true;

        await goToIndex(0);

        if (cancelled) {
          return;
        }

        setPlaying(true);
        setPendingSimulationRequest(null);
        onSimulationRequestApplied?.();
      } catch (error) {
        console.error("Start menu simulation failed:", error);

        if (!cancelled) {
          setPendingSimulationRequest(null);
          onSimulationRequestApplied?.();
        }
      }
    };

    startSimulation();

    return () => {
      cancelled = true;
    };
  }, [
    pendingSimulationRequest,
    items,
    goToIndex,
    clearCapturedFrames,
    onSimulationRequestApplied,
  ]);

  // =====================================================
  // SHOW/HIDE GRID
  // =====================================================

  const handleShowGridChange = useCallback(
    async (checked) => {
      setShowGrid(checked);

      if (!simulationActivatedRef.current) {
        return;
      }

      if (!items.length || index < 0 || index >= items.length) {
        return;
      }

      try {
        await enqueueViewerTask(async () => {
          const accumulatedObjects = buildAccumulatedObjects(index);

          await isolateObjectsInTrimble(accumulatedObjects, checked);
        });
      } catch (error) {
        console.error("Update grid visibility error:", error);
      }
    },
    [
      items.length,
      index,
      enqueueViewerTask,
      buildAccumulatedObjects,
      isolateObjectsInTrimble,
    ],
  );

  const next = useCallback(async () => {
    setPlaying(false);

    clearTimeout(intervalRef.current);

    await goToIndex(indexRef.current + 1);
  }, [goToIndex]);

  const prev = useCallback(async () => {
    setPlaying(false);

    clearTimeout(intervalRef.current);

    await goToIndex(indexRef.current - 1);
  }, [goToIndex]);

  const togglePlay = useCallback(async () => {
    if (!items.length) {
      return;
    }

    /*
     * PAUSE
     *
     * Keep all existing frames. The next Play continues the same recording.
     */
    if (playing) {
      setPlaying(false);

      simulationPausedRef.current = true;

      clearTimeout(intervalRef.current);

      return;
    }

    /*
     * RESUME
     */
    if (simulationPausedRef.current && recordingSimulationRef.current) {
      simulationPausedRef.current = false;

      setPlaying(true);

      return;
    }

    /*
     * NEW RUN
     *
     * Every new simulation starts from item 0 and resets old frames.
     */
    clearCapturedFrames();

    await removeSimulationTextMarkup();

    recordingSimulationRef.current = true;
    simulationPausedRef.current = false;

    indexRef.current = 0;
    setIndex(0);

    await goToIndex(0);

    setPlaying(true);
  }, [
    items.length,
    playing,
    goToIndex,
    clearCapturedFrames,
    removeSimulationTextMarkup,
  ]);

  // =====================================================
  // AUTO PLAY
  // =====================================================

  useEffect(() => {
    if (!playing || !items.length) {
      clearTimeout(intervalRef.current);

      return;
    }

    let cancelled = false;

    const scheduleNext = () => {
      clearTimeout(intervalRef.current);

      intervalRef.current = setTimeout(async () => {
        if (cancelled) {
          return;
        }

        const nextIndex = indexRef.current + 1;

        if (nextIndex >= items.length) {
          /*
           * Keep frames in simulationVideoService for TopMenu export.
           */
          recordingSimulationRef.current = false;
          simulationPausedRef.current = false;

          setPlaying(false);

          console.log("Simulation finished.");

          return;
        }

        /*
         * Wait for the complete Viewer task before scheduling
         * the next simulation step. No async overlap.
         */
        await goToIndex(nextIndex);

        if (cancelled) {
          return;
        }

        scheduleNext();
      }, delay);
    };

    scheduleNext();

    return () => {
      cancelled = true;

      clearTimeout(intervalRef.current);
    };
  }, [playing, delay, items.length, goToIndex]);

  useEffect(() => {
    return () => {
      recordingSimulationRef.current = false;
      clearTimeout(intervalRef.current);

      const tcapi = tcapiRef.current;

      if (!tcapi) {
        return;
      }

      const markupId = simulationTextMarkupIdRef.current;

      simulationTextMarkupIdRef.current = null;

      simulationTextMarkupTaskIdRef.current += 1;

      /*
       * Append reset after all pending viewer mutations.
       * This avoids an older queued task overwriting the cleanup reset.
       */
      viewerTaskRef.current = viewerTaskRef.current
        .catch(() => {})
        .then(async () => {
          try {
            if (markupId != null) {
              await tcapi.markup.removeMarkups([markupId]);
            }

            await tcapi.viewer.setOpacity(0);

            await tcapi.viewer.setObjectState(undefined, {
              visible: "reset",
              color: "reset",
              opacity: 1,
            });
          } catch (error) {
            console.error("Reset simulation viewer state failed:", error);
          }
        });
    };
  }, []);

  // =====================================================
  // SLIDER MARKS
  // =====================================================

  const marks = useMemo(() => {
    return items.reduce((result, item, itemIndex) => {
      result[item.value] = {
        label: (
          <div
            onClick={() => {
              setPlaying(false);

              clearTimeout(intervalRef.current);

              goToIndex(itemIndex);
            }}
            style={{
              width: 8,
              height: 8,
              borderRadius: "50%",
              cursor: "pointer",
            }}
          />
        ),
      };

      return result;
    }, {});
  }, [items, goToIndex]);

  // =====================================================
  // FILTER HANDLERS
  // =====================================================

  const handlePlanChange = (values) => {
    setPlaying(false);
    setIndex(0);

    clearTimeout(intervalRef.current);

    const nextValues = Array.isArray(values) ? values.map(String) : [];

    /*
     * "All Plans" selects every Plan ID.
     * The special value itself is never stored in state.
     */
    if (nextValues.includes(ALL_PLANS_VALUE)) {
      const allPlanIds = plans.map((plan) => String(plan.id));

      setSelectedPlanIds(allPlanIds);

      /*
       * Selecting all Plans should also make all SubPlans
       * available and selected.
       */
      const allSubPlanIds = subPlans.map((subPlan) => String(subPlan.id));

      setSelectedSubPlanIds(allSubPlanIds);

      return;
    }

    setSelectedPlanIds(nextValues);
  };

  const handleSubPlanChange = (values) => {
    setPlaying(false);
    setIndex(0);

    clearTimeout(intervalRef.current);

    const nextValues = Array.isArray(values) ? values.map(String) : [];

    /*
     * "All Sub Plans" selects every SubPlan that is currently
     * available under the selected Plans.
     */
    if (nextValues.includes(ALL_SUBPLANS_VALUE)) {
      setSelectedSubPlanIds(
        availableSubPlans.map((subPlan) => String(subPlan.id)),
      );

      return;
    }

    setSelectedSubPlanIds(nextValues);
  };

  const handleStartDateChange = (date) => {
    setPlaying(false);
    setIndex(0);

    clearTimeout(intervalRef.current);

    setStartDate(date);

    if (date && endDate && date.isAfter(endDate, "day")) {
      setEndDate(null);
    }
  };

  const handleEndDateChange = (date) => {
    setPlaying(false);
    setIndex(0);

    clearTimeout(intervalRef.current);

    setEndDate(date);

    if (date && startDate && date.isBefore(startDate, "day")) {
      setStartDate(null);
    }
  };

  // =====================================================
  // EMPTY DATA
  // =====================================================

  if (!allItems.length) {
    return <div>There is no simulation data available</div>;
  }

  // =====================================================
  // JSX
  // =====================================================

  return (
    <div style={{ width: "100%" }}>
      {/* FILTERS */}
      <div
        style={{
          width: "100%",
          marginBottom: 24,
        }}
      >
        {/* PLAN + GRID */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            width: "100%",
            marginBottom: 8,
          }}
        >
          <Select
            mode="multiple"
            size="small"
            allowClear
            showSearch
            maxTagCount="responsive"
            value={selectedPlanIds}
            placeholder="Select plans"
            optionFilterProp="label"
            onChange={handlePlanChange}
            style={{
              flex: 1,
              minWidth: 0,
            }}
            options={[
              {
                value: ALL_PLANS_VALUE,

                label: "All Plans",
              },

              ...plans.map((plan) => ({
                value: String(plan.id),

                label: plan.name || "Unnamed Plan",
              })),
            ]}
          />

          <Tooltip title={showGrid ? "Hide Grid" : "Show Grid"}>
            <Switch
              checked={showGrid}
              onChange={handleShowGridChange}
              size="small"
            />
          </Tooltip>
        </div>

        {/* SUB PLAN */}
        <div
          style={{
            width: "100%",
            marginBottom: 8,
          }}
        >
          <Select
            mode="multiple"
            size="small"
            allowClear
            showSearch
            maxTagCount="responsive"
            value={selectedSubPlanIds}
            placeholder="Select sub plans"
            optionFilterProp="label"
            onChange={handleSubPlanChange}
            disabled={!availableSubPlans.length}
            style={{
              width: "100%",
            }}
            options={[
              {
                value: ALL_SUBPLANS_VALUE,

                label: "All Sub Plans",
              },

              ...availableSubPlans.map((subPlan) => {
                const subPlanPlanId = subPlan.planId ?? subPlan.parentPlanId;

                const parentPlan = plans.find(
                  (plan) => String(plan.id) === String(subPlanPlanId),
                );

                const subPlanName = subPlan.name || "Unnamed Sub Plan";

                const label = parentPlan?.name
                  ? `${subPlanName} (${parentPlan.name})`
                  : subPlanName;

                return {
                  value: String(subPlan.id),

                  label,
                };
              }),
            ]}
          />
        </div>

        {/* DATE FILTERS */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
            gap: 8,
            width: "100%",
          }}
        >
          <DatePicker
            size="small"
            style={{
              width: "100%",
            }}
            format="DD-MM-YYYY"
            placeholder="Start Date"
            value={startDate}
            onChange={handleStartDateChange}
            disabledDate={(date) => {
              if (!endDate) {
                return false;
              }

              return date.isAfter(endDate, "day");
            }}
          />

          <DatePicker
            size="small"
            style={{
              width: "100%",
            }}
            format="DD-MM-YYYY"
            placeholder="End Date"
            value={endDate}
            onChange={handleEndDateChange}
            disabledDate={(date) => {
              if (!startDate) {
                return false;
              }

              return date.isBefore(startDate, "day");
            }}
          />
        </div>
      </div>

      {!selectedPlanIds.length ? (
        <div>Please select at least one plan</div>
      ) : !items.length ? (
        <div>No available objects match the selected plans and date range</div>
      ) : (
        <>
          {/* CURRENT ITEM */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: 12,
              marginBottom: 8,
              fontWeight: 600,
              fontSize: 16,
            }}
          >
            <span>{current?.planName || "-"}</span>

            <span>
              {`${current?.asmPos ?? ""} Grid: ${current?.positionCode ?? ""}`}
            </span>

            <span>
              {displayWeight != null
                ? `${displayWeight} ${displayWeightUnit}`
                : "-"}
            </span>

            <span>{current?.simulationDate || "-"}</span>
          </div>

          {/* SIMULATION SLIDER */}
          <Slider
            style={{
              width: "100%",
            }}
            min={0}
            max={100}
            value={current?.value ?? 0}
            marks={marks}
            tooltip={{
              open: false,
            }}
            onChange={(value) => {
              const nearestIndex = items.reduce(
                (bestIndex, item, itemIndex) => {
                  const currentDistance = Math.abs(item.value - value);

                  const bestDistance = Math.abs(items[bestIndex].value - value);

                  return currentDistance < bestDistance ? itemIndex : bestIndex;
                },
                0,
              );

              setPlaying(false);

              clearTimeout(intervalRef.current);

              goToIndex(nearestIndex);
            }}
          />

          {/* CONTROLS */}
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: 16,
            }}
          >
            <Space>
              <Button
                icon={<StepBackwardOutlined />}
                onClick={prev}
                disabled={index === 0}
              />

              <Button
                type="primary"
                shape="circle"
                icon={
                  playing ? <PauseCircleOutlined /> : <PlayCircleOutlined />
                }
                onClick={togglePlay}
              />

              <Button
                icon={<StepForwardOutlined />}
                onClick={next}
                disabled={index === items.length - 1}
              />
            </Space>
          </div>

          {/* VIDEO EXPORT */}

          {/* SPEED */}
          <div
            style={{
              marginTop: 12,
            }}
          >
            <span>Timing: {delay} ms</span>

            <Slider
              min={50}
              max={5000}
              step={50}
              value={delay}
              onChange={setDelay}
              tooltip={{
                formatter: (value) => `${value} ms`,
              }}
            />
          </div>
          <div style={{ marginTop: 12 }}>
            <span>Transparency: {transparency}%</span>

            <Slider
              min={0}
              max={100}
              step={5}
              value={transparency}
              onChange={handleTransparencyChange1}
              tooltip={{
                formatter: (value) => `${value}%`,
              }}
            />
          </div>
        </>
      )}
    </div>
  );
}
